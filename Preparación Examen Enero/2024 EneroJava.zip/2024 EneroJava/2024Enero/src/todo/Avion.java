package todo;

import java.util.*;

public class Avion {

    private List<Alquiler> alquiler;

    public Avion(){
        alquiler = new ArrayList<Alquiler>();
    }

    protected void addAlquiler(Alquiler a){alquiler.add(a);}

    protected void rmAlquiler(Alquiler a){alquiler.remove(a);}

    public Enumeration<Alquiler> getAlquiler(){
        return Collections.enumeration(alquiler);
    }

    protected int alquilerMayor4Anios(){
        Enumeration<Alquiler> it = this.getAlquiler();
        int cont = 0;
        while(it.hasMoreElements()){
            if (it.nextElement().duration>4) cont++;
        }
        return cont;
    }
    protected boolean alquiladoEn(Aerolinea a){
        Enumeration<Alquiler> it = this.getAlquiler();
        while(it.hasMoreElements()){
            if (it.nextElement().aerolinea==a) return true;
        }
        return false;
    }
    protected boolean sinSolapamientos(){
        Enumeration<Alquiler> it1 = this.getAlquiler();
        Enumeration<Alquiler> it2 = this.getAlquiler();
        while (it1.hasMoreElements()){
            while (it2.hasMoreElements()){
                if (it1.nextElement()!=it2.nextElement() &&
                        it1.nextElement().comienzo==it2.nextElement().comienzo)
                    return false;
            }
        }
        return true;
    }
}
